<?php
session_start();
include 'db.php';

// Check if user is logged in [cite: 31]
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Handle Delete Request [cite: 61]
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM users WHERE id=$id");
    header("Location: dashboard.php");
}

// Fetch all users
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function confirmDelete(id) {
            // Confirmation Dialog [cite: 63]
            if(confirm("Are you sure you want to delete this record?")) {
                window.location.href = "dashboard.php?delete=" + id;
            }
        }
    </script>
</head>
<body>
    <div class="dashboard-container">
        <div class="header">
            <div>
                <h2>Record Management System</h2>
                <span class="subtitle">Welcome, <?php echo $_SESSION['fullname']; ?></span>
            </div>
            <a href="logout.php" class="btn btn-sm" style="background:#333;">Logout</a>
        </div>

        <div class="card">
            <div class="header" style="margin-bottom:0;">
                <div>
                    <h3>User Management</h3>
                    <p class="subtitle" style="margin-bottom:0;">Manage system users and records</p>
                </div>
                <a href="form.php" class="btn btn-primary btn-sm">Add User</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['fullname']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['username']; ?></td>
                            <td><?php echo $row['user_role']; ?></td>
                            <td>
                                <a href="form.php?edit=<?php echo $row['id']; ?>" class="btn btn-sm" style="background:#eab308;">Edit</a>
                                <button onclick="confirmDelete(<?php echo $row['id']; ?>)" class="btn btn-sm btn-danger">Delete</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="empty-state">No users found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>